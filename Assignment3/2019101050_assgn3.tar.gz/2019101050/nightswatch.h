//
// Created by Pulak Malhotra on 02/09/20.
//

#ifndef UNTITLED_NIGHTSWATCH_H
#define UNTITLED_NIGHTSWATCH_H


void nightswatch_handler(char* tokens[], int no);


#endif //UNTITLED_NIGHTSWATCH_H
