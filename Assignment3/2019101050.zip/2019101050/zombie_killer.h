//
// Created by Pulak Malhotra on 01/09/20.
//

#ifndef UNTITLED_ZOMBIE_KILLER_H
#define UNTITLED_ZOMBIE_KILLER_H
void zombie_process_check();
void killbg();

#endif //UNTITLED_ZOMBIE_KILLER_H
