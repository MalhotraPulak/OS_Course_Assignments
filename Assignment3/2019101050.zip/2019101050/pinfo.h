//
// Created by Pulak Malhotra on 31/08/20.
//

#ifndef UNTITLED_PINFO_H
#define UNTITLED_PINFO_H

void pinfo_handler(char * tokens[]);


#endif //UNTITLED_PINFO_H
