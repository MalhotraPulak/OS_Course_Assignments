//
// Created by Pulak Malhotra on 15/09/20.
//

#ifndef OS_ASSIGNMENTS_ENV_VAR_H
#define OS_ASSIGNMENTS_ENV_VAR_H

void setenv_handler(char *tokens[], int num);
void getenv_handler(char *tokens[], int num);
void unsetenv_handler(char *tokens[], int num);

#endif //OS_ASSIGNMENTS_ENV_VAR_H
