//
// Created by Pulak Malhotra on 15/09/20.
//

#ifndef OS_ASSIGNMENTS_PARSER_H
#define OS_ASSIGNMENTS_PARSER_H



void getIndividualCommands(char *);


#endif //OS_ASSIGNMENTS_PARSER_H
