### How to run
```
> make 
```
- This will create two executables server and client
- Call the executables from the folders as required
- Run server first then client
- get and exit command as specified
