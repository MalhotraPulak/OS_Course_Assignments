make TOOLPREFIX=i386-elf- clean
make TOOLPREFIX=i386-elf- qemu-nox SCHEDULER=$1
