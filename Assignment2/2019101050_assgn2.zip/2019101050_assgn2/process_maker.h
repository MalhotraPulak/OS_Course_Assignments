//
// Created by Pulak Malhotra on 31/08/20.
//

#ifndef UNTITLED_PROCESS_MAKER_H
#define UNTITLED_PROCESS_MAKER_H

void make_process(char *tokens[], int num, int bg);
#endif //UNTITLED_PROCESS_MAKER_H
