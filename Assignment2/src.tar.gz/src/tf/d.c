for i in range(50000000):
	j = 0
