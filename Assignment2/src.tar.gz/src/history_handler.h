//
// Created by Pulak Malhotra on 01/09/20.
//

#ifndef UNTITLED_HISTORY_HANDLER_H
#define UNTITLED_HISTORY_HANDLER_H
void add_history(char * tokens);
void show_history(int n);
#endif //UNTITLED_HISTORY_HANDLER_H
