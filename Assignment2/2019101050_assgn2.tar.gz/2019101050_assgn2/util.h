//
// Created by Pulak Malhotra on 31/08/20.
//

#ifndef UNTITLED_UTIL_H
#define UNTITLED_UTIL_H
void get_raw_address(char *new_address, char *cd_location,const char* curr_dir, const char* home_dir);

void printGreen();

void printBlue();
void printYellow();
void printCyan();
void welcomeMessage();
void resetColor();
void clearScreen();
int max(int a, int b);
int min(int a, int b);

#endif //UNTITLED_UTIL_H
