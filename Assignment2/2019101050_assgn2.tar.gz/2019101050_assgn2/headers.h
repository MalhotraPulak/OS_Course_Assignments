//
// Created by Pulak Malhotra on 31/08/20.
//

#ifndef UNTITLED_HEADERS_H
#define UNTITLED_HEADERS_H
#include<stdio.h>
#include<unistd.h>
#include<sys/utsname.h>
#include<stdlib.h>
#include<string.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <pwd.h>
#include <grp.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <stdbool.h>
#define size_buff 5000
#endif //UNTITLED_HEADERS_H
