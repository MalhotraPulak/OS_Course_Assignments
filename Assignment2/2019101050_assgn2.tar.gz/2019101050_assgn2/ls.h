//
// Created by Pulak Malhotra on 31/08/20.
//

#ifndef UNTITLED_LS_H
#define UNTITLED_LS_H
void ls_handler(char *tokens[], int no, const char* curr_dir, const char * home_dir);
//void print_ls_data(const char *location, int hidden, int details, int file, char *outName);
#endif //UNTITLED_LS_H
