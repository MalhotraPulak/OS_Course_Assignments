make
./shell
