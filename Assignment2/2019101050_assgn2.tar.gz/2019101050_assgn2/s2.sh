gcc -g -o sd shell.c pinfo.c process_maker.c util.c ls.c history_handler.c zombie_killer.c nightswatch.c
gdb ./sd
