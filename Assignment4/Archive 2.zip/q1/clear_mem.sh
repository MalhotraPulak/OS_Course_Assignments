for i in {14..76}
do
  ipcrm -m $i
done
