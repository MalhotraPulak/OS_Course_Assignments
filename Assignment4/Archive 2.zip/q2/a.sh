gcc q2_sync.c -lpthread -o q2
./q2 < input.txt
