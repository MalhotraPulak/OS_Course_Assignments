rm q3
gcc q3.c -pthread -o q3
./q3 < input4.txt
