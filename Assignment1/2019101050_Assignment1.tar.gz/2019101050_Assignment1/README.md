#### 2019101050 Pulak Malhotra
- Reading 1e6 bytes per read operation
- Progress is updated after every 0.01 percent increase
- Newline treated as normal byte
- Max length of file address is for q1 is 999 characters 
- In second question path of newfile, oldfile and directory is assumed to given as per question, I'm *not* looking for the newfile inside the directory, I assume the actual path of newfile is given 
