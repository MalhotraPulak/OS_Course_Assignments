#### 2019101050 Pulak Malhotra
- Reading 1e6 bytes per read operation

