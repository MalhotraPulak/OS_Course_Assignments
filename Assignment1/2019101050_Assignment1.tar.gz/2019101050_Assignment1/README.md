#### 2019101050 Pulak Malhotra
- Reading 1e6 bytes per read operation
- Progress is updated after every 0.01 percent increase
- Newline treated as normal byte

